package com.mart.entity;

public enum OrderStatus {
    PENDING_PAYMENT,
    PAID,
    CANCELLED,
    SHIPPED
}