package com.mart.dto;

import lombok.Data;

@Data
public class GoogleTokenRequest {
    private String token;
}
