package com.mart.entity;

public enum Role {
    ADMIN,
    SELLER,
    CUSTOMER
}
